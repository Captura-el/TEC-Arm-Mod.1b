/******************************************************************************
 * @file:    main.c
 * @purpose: uso de funciones incluidas en cmsis-core y manejo de interrupciones
 *
******************************************************************************/
      
#include "ARMCM7.h"                     // Device header

          
//extern void SysTick_Handler (void);
volatile uint32_t msTicks;                  // Counts 1ms timeTicks
uint32_t MiCPU;
uint32_t contador =0;

/*-----------------------------------------------------------------------------
  SysTick_Handler
*----------------------------------------------------------------------------*/
extern void SysTick_Handler (void)  {
  msTicks++;    	// Increment counter
	// __disable_irq();
}

/*-----------------------------------------------------------------------------
  leer CPUID
*----------------------------------------------------------------------------*/
uint32_t read_cpuid(void) {
  return SCB->CPUID;  // CPUID Base Register
}

/*-----------------------------------------------------------------------------
  MAIN function
*----------------------------------------------------------------------------*/
int main (void)  {
	
	uint32_t resultado =0;

	resultado = SysTick_Config (SystemCoreClock/1000);    // Configure the SYSTICK
	MiCPU = read_cpuid();
	__NOP();
	
	while (1) {
		contador++;
	} ;
	return contador;
}



