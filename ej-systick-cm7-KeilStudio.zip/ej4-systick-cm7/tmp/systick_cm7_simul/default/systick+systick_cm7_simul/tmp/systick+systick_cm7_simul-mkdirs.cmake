# Distributed under the OSI-approved BSD 3-Clause License.  See accompanying
# file Copyright.txt or https://cmake.org/licensing for details.

cmake_minimum_required(VERSION ${CMAKE_VERSION}) # this file comes with cmake

# If CMAKE_DISABLE_SOURCE_CHANGES is set to true and the source directory is an
# existing directory in our source tree, calling file(MAKE_DIRECTORY) on it
# would cause a fatal error, even though it would be a no-op.
if(NOT EXISTS "C:/DATOS/arm-curso/curso-m1b/ej4-systick-cm7/tmp/systick_cm7_simul/default/systick+systick_cm7_simul")
  file(MAKE_DIRECTORY "C:/DATOS/arm-curso/curso-m1b/ej4-systick-cm7/tmp/systick_cm7_simul/default/systick+systick_cm7_simul")
endif()
file(MAKE_DIRECTORY
  "C:/DATOS/arm-curso/curso-m1b/ej4-systick-cm7/tmp/systick_cm7_simul/default/1"
  "C:/DATOS/arm-curso/curso-m1b/ej4-systick-cm7/tmp/systick_cm7_simul/default/systick+systick_cm7_simul"
  "C:/DATOS/arm-curso/curso-m1b/ej4-systick-cm7/tmp/systick_cm7_simul/default/systick+systick_cm7_simul/tmp"
  "C:/DATOS/arm-curso/curso-m1b/ej4-systick-cm7/tmp/systick_cm7_simul/default/systick+systick_cm7_simul/src/systick+systick_cm7_simul-stamp"
  "C:/DATOS/arm-curso/curso-m1b/ej4-systick-cm7/tmp/systick_cm7_simul/default/systick+systick_cm7_simul/src"
  "C:/DATOS/arm-curso/curso-m1b/ej4-systick-cm7/tmp/systick_cm7_simul/default/systick+systick_cm7_simul/src/systick+systick_cm7_simul-stamp"
)

set(configSubDirs )
foreach(subDir IN LISTS configSubDirs)
    file(MAKE_DIRECTORY "C:/DATOS/arm-curso/curso-m1b/ej4-systick-cm7/tmp/systick_cm7_simul/default/systick+systick_cm7_simul/src/systick+systick_cm7_simul-stamp/${subDir}")
endforeach()
if(cfgdir)
  file(MAKE_DIRECTORY "C:/DATOS/arm-curso/curso-m1b/ej4-systick-cm7/tmp/systick_cm7_simul/default/systick+systick_cm7_simul/src/systick+systick_cm7_simul-stamp${cfgdir}") # cfgdir has leading slash
endif()
