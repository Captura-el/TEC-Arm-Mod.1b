./objects/main.o: STM32CubeMX\Target_1\STM32CubeMX\Src\main.c \
  STM32CubeMX\Target_1\STM32CubeMX\Inc\main.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32F7xx_HAL_Driver\Inc\stm32f7xx_hal.h \
  STM32CubeMX\Target_1\STM32CubeMX\Inc\stm32f7xx_hal_conf.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32F7xx_HAL_Driver\Inc\stm32f7xx_hal_rcc.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32F7xx_HAL_Driver\Inc\stm32f7xx_hal_def.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\CMSIS\Device\ST\STM32F7xx\Include\stm32f7xx.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\CMSIS\Device\ST\STM32F7xx\Include\stm32f746xx.h \
  C:\Users\adam\AppData\Local\arm\packs\ARM\CMSIS\6.3.0\CMSIS\Core\Include\core_cm7.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\CMSIS\Device\ST\STM32F7xx\Include\system_stm32f7xx.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32F7xx_HAL_Driver\Inc\Legacy\stm32_hal_legacy.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32F7xx_HAL_Driver\Inc\stm32f7xx_hal_rcc_ex.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32F7xx_HAL_Driver\Inc\stm32f7xx_hal_exti.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32F7xx_HAL_Driver\Inc\stm32f7xx_hal_gpio.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32F7xx_HAL_Driver\Inc\stm32f7xx_hal_gpio_ex.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32F7xx_HAL_Driver\Inc\stm32f7xx_hal_dma.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32F7xx_HAL_Driver\Inc\stm32f7xx_hal_dma_ex.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32F7xx_HAL_Driver\Inc\stm32f7xx_hal_cortex.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32F7xx_HAL_Driver\Inc\stm32f7xx_hal_flash.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32F7xx_HAL_Driver\Inc\stm32f7xx_hal_flash_ex.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32F7xx_HAL_Driver\Inc\stm32f7xx_hal_i2c.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32F7xx_HAL_Driver\Inc\stm32f7xx_hal_i2c_ex.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32F7xx_HAL_Driver\Inc\stm32f7xx_hal_pwr.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32F7xx_HAL_Driver\Inc\stm32f7xx_hal_pwr_ex.h
