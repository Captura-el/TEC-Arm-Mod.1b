# Distributed under the OSI-approved BSD 3-Clause License.  See accompanying
# file LICENSE.rst or https://cmake.org/licensing for details.

cmake_minimum_required(VERSION ${CMAKE_VERSION}) # this file comes with cmake

# If CMAKE_DISABLE_SOURCE_CHANGES is set to true and the source directory is an
# existing directory in our source tree, calling file(MAKE_DIRECTORY) on it
# would cause a fatal error, even though it would be a no-op.
if(NOT EXISTS "C:/DATOS/arm/Boards/ST/NUCLEO-F746ZG/Blinky2/tmp/NUCLEO-F756ZG/default/Blinky.Debug+NUCLEO-F756ZG")
  file(MAKE_DIRECTORY "C:/DATOS/arm/Boards/ST/NUCLEO-F746ZG/Blinky2/tmp/NUCLEO-F756ZG/default/Blinky.Debug+NUCLEO-F756ZG")
endif()
file(MAKE_DIRECTORY
  "C:/DATOS/arm/Boards/ST/NUCLEO-F746ZG/Blinky2/tmp/NUCLEO-F756ZG/default/1"
  "C:/DATOS/arm/Boards/ST/NUCLEO-F746ZG/Blinky2/tmp/NUCLEO-F756ZG/default/Blinky.Debug+NUCLEO-F756ZG"
  "C:/DATOS/arm/Boards/ST/NUCLEO-F746ZG/Blinky2/tmp/NUCLEO-F756ZG/default/Blinky.Debug+NUCLEO-F756ZG/tmp"
  "C:/DATOS/arm/Boards/ST/NUCLEO-F746ZG/Blinky2/tmp/NUCLEO-F756ZG/default/Blinky.Debug+NUCLEO-F756ZG/src/Blinky.Debug+NUCLEO-F756ZG-stamp"
  "C:/DATOS/arm/Boards/ST/NUCLEO-F746ZG/Blinky2/tmp/NUCLEO-F756ZG/default/Blinky.Debug+NUCLEO-F756ZG/src"
  "C:/DATOS/arm/Boards/ST/NUCLEO-F746ZG/Blinky2/tmp/NUCLEO-F756ZG/default/Blinky.Debug+NUCLEO-F756ZG/src/Blinky.Debug+NUCLEO-F756ZG-stamp"
)

set(configSubDirs )
foreach(subDir IN LISTS configSubDirs)
    file(MAKE_DIRECTORY "C:/DATOS/arm/Boards/ST/NUCLEO-F746ZG/Blinky2/tmp/NUCLEO-F756ZG/default/Blinky.Debug+NUCLEO-F756ZG/src/Blinky.Debug+NUCLEO-F756ZG-stamp/${subDir}")
endforeach()
if(cfgdir)
  file(MAKE_DIRECTORY "C:/DATOS/arm/Boards/ST/NUCLEO-F746ZG/Blinky2/tmp/NUCLEO-F756ZG/default/Blinky.Debug+NUCLEO-F756ZG/src/Blinky.Debug+NUCLEO-F756ZG-stamp${cfgdir}") # cfgdir has leading slash
endif()
