./objects/system_cmsdk_cm7.o: RTE\Device\CMSDK_CM7\system_CMSDK_CM7.c \
  C:\Users\adam\AppData\Local\arm\packs\Keil\V2M-MPS2_CMx_BSP\1.8.2\Device\CMSDK_CM7\Include\CMSDK_CM7.h \
  C:\Users\adam\AppData\Local\arm\packs\ARM\CMSIS\6.2.0\CMSIS\Core\Include\core_cm7.h \
  C:\Users\adam\AppData\Local\arm\packs\Keil\V2M-MPS2_CMx_BSP\1.8.2\Device\CMSDK_CM7\Include\system_CMSDK_CM7.h
