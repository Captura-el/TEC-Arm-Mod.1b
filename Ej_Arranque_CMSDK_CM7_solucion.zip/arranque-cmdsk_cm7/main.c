#include "CMSDK_CM7.h"                  // Device header

int main(void) {

 while(1) {

 };

} 